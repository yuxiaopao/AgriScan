import {Xiaohe} from './Xiaohe'
import DetectionJourney from './DetectionJourney'
import {AccountEmailSettings} from './EmailForms'
import DetectResultView from './DetectResultView'
import {DetectionTaskProgress,taskFinished,type DetectionTasksBinding} from './DetectionTasks'
import {ExportButton, reducedMotion} from './motion'
import {useClientConfiguration} from './ClientConfig'
import {CropRoom} from './CropRoom'
import {useCropTheme} from './CropTheme'
import {XiaoheMotionDemo} from './XiaoheMotionDemo'
import PlotEditor from './PlotEditor'
import PlotCoverCarousel from './PlotCoverCarousel'
import DetectionImageComparison from './DetectionImageComparison'
import RunningModels from './RunningModels'
import type {ReactNode} from 'react'
import {useEffect, useRef, useState, type FormEvent} from 'react'
import {ArrowUpRight, BookOpen, Check, CheckCircle2, CircleAlert, CloudUpload, FileImage, Filter, FlaskConical, HardDrive, Layers3, Leaf, LoaderCircle, MapPin, Pencil, Plus, ScanLine, Search, Server, Settings2, ShieldCheck, Sprout, Trash2, Upload, X} from 'lucide-react'
import {api, downloadCsv, getToken} from './api'
import {CropIcon, DetectionTable, Empty, Modal, statusLabels} from './components'
import type {Article, Detection, Health, ModelInfo, Plot, User} from './types'

interface ProtectedProps {requireAuth: () => boolean; onChange: () => void; toast: (message: string) => void}
export function DetectPage({plots,model,requireAuth,toast,tasks,onViewAdvice}:{plots:Plot[];model:ModelInfo;tasks:DetectionTasksBinding;onViewAdvice?:(record:Detection)=>void}&ProtectedProps){
  const client=useClientConfiguration(),imageMax=client.limits.image_max_mb
  const [file,setFile]=useState<File|null>(null),[preview,setPreview]=useState(''),[plotId,setPlotId]=useState(''),[note,setNote]=useState(''),[dragging,setDragging]=useState(false),[submitError,setSubmitError]=useState('')
  const {crop,setCrop}=useCropTheme()
  const selectedJob=tasks.jobs.find(job=>job.key===tasks.selectedKey)
  const result=selectedJob?.status==='completed'?tasks.records[selectedJob.key]??null:null
  const busy=Boolean(selectedJob&&!taskFinished(selectedJob))
  const completedUpload=useRef(false),acceptedToken=useRef<string|null>(null),previewKey=useRef<string|null>(null),mounted=useRef(true),viewedKey=useRef(tasks.selectedKey)
  viewedKey.current=tasks.selectedKey
  const input=useRef<HTMLInputElement>(null),details=useRef<HTMLDivElement>(null),resultHeading=useRef<HTMLHeadingElement>(null),resultMetadata=useRef<HTMLDetailsElement>(null),resultPanel=useRef<HTMLElement>(null)
  useEffect(()=>{mounted.current=true;return()=>{mounted.current=false}},[])
  const scrollTo=(node:HTMLElement|null)=>node?.scrollIntoView({block:'center',behavior:reducedMotion()?'instant':'smooth'})
  const modelReady=model.status==='ready',crops=modelReady?model.supported_crops:model.available_crops
  const selectablePlots=modelReady?plots:plots.filter(plot=>plot.crop===crop)
  const recognized=result&&result.status!=='awaiting_model'?result:null
  const fileOverLimit=Boolean(file&&file.size>imageMax*1024*1024)
  useEffect(()=>{if(!client.features.plots&&!busy)setPlotId('')},[client.features.plots,busy])
  useEffect(()=>{if(!client.features.image_detection)setDragging(false)},[client.features.image_detection])
  useEffect(()=>{if(!result&&!modelReady&&crops.length&&!crops.includes(crop)){setCrop(crops[0]);setPlotId('')}},[crops,crop,modelReady,setCrop,result])
  const selectCrop=(next:string)=>{if(busy||crop===next||(!crops.includes(next)&&!(modelReady&&model.available_crops.includes(next))))return;setCrop(next);if(!modelReady)setPlotId('')}
  useEffect(()=>{if(!file){setPreview('');return};const url=URL.createObjectURL(file);setPreview(url);return()=>URL.revokeObjectURL(url)},[file])
  useEffect(()=>{
    if(!result||!tasks.selectedKey)return
    const token=getToken(),key=tasks.selectedKey
    if(!token)return
    acceptedToken.current=token
    if(result.status!=='awaiting_model')setCrop(result.crop)
    const frame=requestAnimationFrame(()=>{if(!mounted.current||getToken()!==token||viewedKey.current!==key||document.querySelector('[role="dialog"]'))return;resultHeading.current?.focus({preventScroll:true});resultHeading.current?.scrollIntoView({block:'start',behavior:reducedMotion()?'instant':'smooth'})})
    return()=>cancelAnimationFrame(frame)
  },[result?.id,tasks.selectedKey,tasks.viewVersion,setCrop])
  const openPicker=()=>{if(!client.features.image_detection)return;if(input.current){input.current.value='';input.current.click()}}
  const removeFile=()=>{completedUpload.current=false;acceptedToken.current=null;previewKey.current=null;setFile(null);setSubmitError('');if(input.current)input.current.value=''}
  const chooseFile=(next?:File)=>{
    if(!next||!client.features.image_detection)return
    if(!['image/jpeg','image/png','image/webp'].includes(next.type)){toast('请选择 JPG、PNG 或 WebP 格式的图片。');return}
    if(next.size>imageMax*1024*1024){toast(`图片不能超过 ${imageMax} MB，请压缩后重新选择。`);return}
    completedUpload.current=false;acceptedToken.current=null;previewKey.current=null;tasks.select(null);setFile(next);setSubmitError('')
  }
  function submit(event:FormEvent){
    event.preventDefault()
    if(completedUpload.current||!file||fileOverLimit||!client.features.image_detection||!requireAuth())return
    if(!tasks.manager){setSubmitError('检测任务正在准备，请稍后重试。');return}
    completedUpload.current=true;setDragging(false);setSubmitError('')
    try{
      const key=tasks.manager.enqueue({file,kind:'image',note,...(!modelReady?{crop}:{}),...(plotId&&client.features.plots?{plot_id:plotId}:{})})
      previewKey.current=key;tasks.select(key);toast('已加入检测任务，可以切换其他模块或继续选择照片。')
    }catch(reason){completedUpload.current=false;setSubmitError((reason as Error).message)}
  }
  return <>
    <input ref={input} type="file" disabled={!client.features.image_detection} accept="image/jpeg,image/png,image/webp" className="sr-only" aria-label="选择作物图片" onClick={event=>{event.currentTarget.value=''}} onChange={event=>chooseFile(event.target.files?.[0])}/>
    <DetectionJourney phase={busy?'detecting':result?(result.status==='awaiting_model'?'saved':'complete'):selectedJob?.status==='failed'?'failed':selectedJob?.status==='cancelled'?'cancelled':selectedJob?.status==='completed'?'result_loading':file?'details':'choose'} modelReady={modelReady} canUpload={client.features.image_detection} onUpload={selectedJob?()=>scrollTo(resultPanel.current):openPicker} onDetails={()=>{if(result){if(resultMetadata.current){resultMetadata.current.open=true;scrollTo(resultMetadata.current);resultMetadata.current.querySelector('summary')?.focus({preventScroll:true})}}else{scrollTo(details.current);details.current?.querySelector<HTMLElement>('select, textarea')?.focus({preventScroll:true})}}} onResult={()=>{scrollTo(resultHeading.current);resultHeading.current?.focus({preventScroll:true})}}/>
    {result?<DetectResultView record={result} originalUrl={previewKey.current===tasks.selectedKey?preview:''} canChoose={client.features.image_detection} canAsk={client.features.assistant&&Boolean(onViewAdvice)} headingRef={resultHeading} comparisonRef={resultPanel} metadataRef={resultMetadata} onChooseNext={openPicker} onViewAdvice={()=>{if(mounted.current&&getToken()===acceptedToken.current)onViewAdvice?.(result)}}/>:selectedJob?<section className="panel detect-running-task" ref={resultPanel}><h2>{selectedJob.filename}</h2><DetectionTaskProgress job={selectedJob}/>{selectedJob.status==='completed'&&<p role="status">{tasks.errors[selectedJob.key]||'正在加载本次结果…'}</p>}<div className="detect-running-task-actions"><button type="button" className="button primary" onClick={openPicker} disabled={!client.features.image_detection}>再检测一张</button>{selectedJob.status==='completed'&&tasks.errors[selectedJob.key]&&<button type="button" className="button outline" onClick={()=>tasks.select(selectedJob.key)}>重新加载结果</button>}{!taskFinished(selectedJob)&&<button type="button" className="button outline" disabled={selectedJob.status==='cancelling'} onClick={()=>void tasks.manager?.cancel(selectedJob.key)}>取消任务</button>}</div></section>:<>
    {submitError&&<div className="form-error detect-upload-error" role="alert">{submitError}</div>}
    <CropRoom crops={crops} availableCrops={model.available_crops} busy={busy} automatic={modelReady} onSelect={selectCrop}/>
    {!client.features.image_detection && <div className="notice" role="status"><ScanLine size={19}/><div><strong>图片检测暂未开放</strong><p>管理员已暂停新上传和新检测，当前照片、备注与已有结果仍保留；重新开放后可以继续。</p></div></div>}
    {fileOverLimit && <div className="notice" role="status"><CircleAlert size={19}/><p>当前图片超过最新的 {imageMax} MB 上限，请重新选择较小图片后再提交。</p></div>}
    <div className={`detect-grid ${result ? 'has-result' : ''}`}><form className="panel upload-panel has-comparison" onSubmit={submit} aria-busy={busy}><div className="panel-header"><h2><span className="step-number">01</span>上传作物图片</h2><span className="quiet">单图检测</span></div>
      <div className="upload-workspace"><DetectionImageComparison originalUrl={preview} record={null} busy={busy} modelReady={modelReady} original={<div className="upload-media">
      <div className={`drop-zone ${dragging ? 'dragging' : ''} ${preview ? 'has-preview' : ''}`} onDragOver={event => {event.preventDefault(); setDragging(!busy && client.features.image_detection)}} onDragLeave={() => setDragging(false)} onDrop={event => {event.preventDefault(); setDragging(false); chooseFile(event.dataTransfer.files[0])}}>
        {preview ? <><img src={preview} className="upload-preview" alt="待检测作物预览"/><button type="button" disabled={busy} className="preview-remove" onClick={removeFile} aria-label="移除已选图片"><X size={18}/></button><div className="file-chip"><FileImage size={15}/><span>{file?.name}</span><small>{((file?.size ?? 0) / 1024 / 1024).toFixed(2)} MB</small></div></> : <><div className="upload-guidance"><h3>拍得清楚，看得更准</h3><ol>{[['自然光线', '避开强烈反光，保留叶片真实颜色。'], ['主体清晰', '靠近叶片拍摄，让病斑与纹理清楚可见。'], ['完整记录', '一次选择一张图片，并补充采集备注。']].map(([title, content], index) => <li key={title}><span>{String(index + 1).padStart(2, '0')}</span><div><strong>{title}</strong><p>{content}</p></div></li>)}</ol></div><button type="button" className="button primary" disabled={busy || !client.features.image_detection} onClick={openPicker}><Upload size={16}/>选择图片</button><span className="upload-hint">支持 JPG、PNG、WebP · 最大 {imageMax} MB</span></>}
      </div>
      {file && <button className="text-button change-file" type="button" disabled={busy || !client.features.image_detection} onClick={openPicker}>重新选择图片</button>}
      </div>}/><div className="form-section" ref={details}><h2><span className="step-number">02</span>检测与样本信息</h2><div className="form-grid">{modelReady ? <div className="crop-auto-status" role="status" aria-live="polite"><span><ScanLine size={15}/>作物识别</span><strong>{busy ? '正在辨认照片中的作物…' : recognized ? `模型识别：${recognized.crop}` : '自动识别，无需选择作物'}</strong><p>{recognized && !busy ? '病害或健康状态与置信度见本次检测结果；主题浏览不会改写结果。' : '点击“识别并保存”后，自动识别作物与叶片状况，并进入对应检测室。'}</p><small>{crops.length} 种作物 · {model.active?.task==='detect'?'叶片目标检测':'单叶图像分类'}</small></div> : <label>采集作物<select value={crop} disabled={busy || !crops.length} onChange={event => selectCrop(event.target.value)}>{crops.map(item => <option key={item}>{item}</option>)}</select></label>}<label>所属地块 <span>（选填）</span><select value={plotId} disabled={busy || !client.features.plots} onChange={event => setPlotId(event.target.value)}><option value="">暂不关联地块</option>{selectablePlots.map(plot => <option key={plot.id} value={plot.id}>{plot.name}{modelReady ? ` · ${plot.crop}` : ''}</option>)}</select>{!client.features.plots ? <small className="auto-plot-hint" role="status">{busy?'管理员已暂停地块关联；当前请求使用提交时的信息，后续检测不关联地块。':'管理员已暂停地块关联，原选择已取消，本次不关联地块。'}</small> : modelReady && <small className="auto-plot-hint">可不关联；所选地块的作物须与照片识别结果一致。</small>}</label></div><label>样本备注 <span>（选填）</span><textarea value={note} disabled={busy} onChange={event => setNote(event.target.value)} maxLength={500} placeholder="例如：叶片出现黄斑，采集于植株中部…" rows={3}/></label></div>
      </div><div className="upload-actions"><span><ShieldCheck size={14}/>图片用于检测与小禾解读</span><button className="button primary detection-submit" type="submit" aria-busy={busy} disabled={!file||busy||fileOverLimit||!client.features.image_detection}>{busy?<LoaderCircle size={17} className="spin"/>:<CloudUpload size={17}/>} {busy?(modelReady?'正在识别…':'正在保存…'):(modelReady?'识别并保存':'保存检测样本')}</button></div>
    </form></div></>}
  </>
}

export function RecordsPage({records, crops, onSelect, search, setSearch, status, setStatus}: {records: Detection[]; crops: string[]; onSelect: (record: Detection) => void; search: string; setSearch: (search: string) => void; status: string; setStatus: (status: string) => void}) {
  const [crop, setCrop] = useState('')
  const [source, setSource] = useState('')
  const [page, setPage] = useState(1)
  const [checked, setChecked] = useState<Set<string>>(new Set())
  const filtered = records.filter(record => `${record.name} ${record.crop} ${record.plot_name} ${record.id}`.toLowerCase().includes(search.toLowerCase()) && (!crop || record.crop === crop) && (!status || record.status === status) && (!source || (source === 'demo' ? record.is_demo : !record.is_demo)))
  const pages = Math.max(1, Math.ceil(filtered.length / 8))
  const currentPage = Math.min(page, pages)
  useEffect(() => {setPage(1); setChecked(new Set())}, [search, crop, status, source])
  const visible = filtered.slice((currentPage - 1) * 8, currentPage * 8)
  const selectedRecords = filtered.filter(record => checked.has(record.id))
  const toggle = (id: string) => setChecked(old => {const next = new Set(old); if (next.has(id)) next.delete(id); else next.add(id); return next})
  const toggleAll = () => setChecked(old => {const next = new Set(old); const all = visible.every(record => next.has(record.id)); visible.forEach(record => all ? next.delete(record.id) : next.add(record.id)); return next})
  return <><section className="panel records-panel"><div className="records-toolbar"><div className="input-search"><Search size={17}/><input aria-label="搜索检测记录" placeholder="搜索样本、作物、地块…" value={search} onChange={event => setSearch(event.target.value)}/>{search && <button className="icon-button" aria-label="清除搜索" onClick={() => setSearch('')}><X size={14}/></button>}</div><div className="filter-selects"><Filter size={16}/><select aria-label="筛选作物" value={crop} onChange={event => setCrop(event.target.value)}><option value="">全部作物</option>{crops.map(item => <option key={item}>{item}</option>)}</select><select aria-label="筛选检测状态" value={status} onChange={event => setStatus(event.target.value)}><option value="">全部状态</option>{Object.entries(statusLabels).map(([key, label]) => <option key={key} value={key}>{label}</option>)}</select><select aria-label="筛选样本来源" value={source} onChange={event => setSource(event.target.value)}><option value="">全部来源</option><option value="upload">上传样本</option><option value="demo">示例样本</option></select></div></div>{filtered.length ? <DetectionTable records={visible} onSelect={onSelect} selected={checked} onToggle={toggle} onToggleAll={toggleAll}/> : <Empty title="没有找到匹配的记录" description="试试其他关键词，或调整筛选条件。"/>}<div className={`record-selection-bar ${selectedRecords.length ? 'has-selection' : ''}`}><span role="status">{selectedRecords.length ? `已选择 ${selectedRecords.length} 份记录` : '勾选记录，可一起导出田间档案'}</span><div>{selectedRecords.length > 0 && <button className="text-button" onClick={() => setChecked(new Set())}>取消选择</button>}<ExportButton disabled={!filtered.length} onAction={() => exportRecords(selectedRecords.length ? selectedRecords : filtered)}>{selectedRecords.length ? '导出所选' : '导出筛选结果'}</ExportButton></div></div><div className="pagination"><span>共 {filtered.length} 条记录 <span className="quiet">· 示例结果仅用于界面演示</span></span><div><button disabled={currentPage <= 1} onClick={() => setPage(currentPage - 1)}>上一页</button><span>{currentPage} / {pages}</span><button disabled={currentPage >= pages} onClick={() => setPage(currentPage + 1)}>下一页</button></div></div></section></>
}

export function exportRecords(records: Detection[]) {
  downloadCsv([['样本编号', '名称', '作物', '地块', '状态', '结果', '置信度', '示例数据', '检测时间', '备注'], ...records.map(record => [record.id, record.name, record.crop, record.plot_name, statusLabels[record.status], record.result, record.confidence, record.is_demo ? '是' : '否', record.created_at, record.note])], `禾观-检测记录-${new Date().toISOString().slice(0, 10)}.csv`)
}

export function PlotsPage({plots, crops, draftOwner, canManage, requireAuth, onChange, toast}: {plots: Plot[]; crops: string[]; draftOwner: string; canManage: boolean} & ProtectedProps) {
  const [editing, setEditing] = useState<Plot | 'new' | null>(null)
  const [deleting, setDeleting] = useState<Plot | null>(null)
  const [busy, setBusy] = useState(false)
  const [search, setSearch] = useState('')
  const filtered = plots.filter(plot => `${plot.name} ${plot.crop} ${plot.location}`.includes(search))
  async function remove() {
    if (!deleting) return
    setBusy(true)
    try {await api(`/plots/${deleting.id}`, {method: 'DELETE'}); setDeleting(null); onChange(); toast('地块已移除，历史样本仍保留。')}
    catch (error) {toast((error as Error).message)}
    finally {setBusy(false)}
  }
  return <><div className="plot-summary"><span><MapPin size={18}/>我的地块 <strong>{plots.length}</strong> 块</span><span><Layers3 size={18}/>总种植面积 <strong>{plots.reduce((sum, plot) => sum + plot.area, 0).toLocaleString(undefined, {maximumFractionDigits: 2})}</strong> 亩</span><div className="input-search"><Search size={16}/><input aria-label="搜索地块" placeholder="查找地块…" value={search} onChange={event => setSearch(event.target.value)}/></div></div><div className="plot-grid">{filtered.map((plot, index) => <article className="panel plot-card" key={plot.id}><PlotCoverCarousel plot={plot} index={index}/><div className="plot-body"><div className="plot-title"><h2>{plot.name}</h2>{canManage && <button className="icon-button" aria-label={`编辑${plot.name}`} onClick={() => {if (requireAuth()) setEditing(plot)}}><Pencil size={16}/></button>}</div><p><MapPin size={13}/>{plot.location || '位置待补充'}</p>{plot.latitude != null && plot.longitude != null && <a className="plot-map-link" href={`https://www.openstreetmap.org/?mlat=${plot.latitude}&mlon=${plot.longitude}#map=18/${plot.latitude}/${plot.longitude}`} target="_blank" rel="noreferrer"><MapPin size={12}/>查看定位<ArrowUpRight size={12}/></a>}<div className="plot-metrics"><div><span>负责人</span><strong>{plot.manager || '未设置'}</strong></div><div><span>检测记录</span><strong>{plot.detections} <small>份</small></strong></div><div><span>历史健康率</span><strong>{plot.health_score == null ? '—' : `${Math.round(plot.health_score)}%`}</strong></div></div><div className="plot-card-footer"><span>健康率根据已有结果统计</span>{canManage && <button aria-label={`删除${plot.name}`} onClick={() => {if (requireAuth()) setDeleting(plot)}}><Trash2 size={14}/></button>}</div></div></article>)}{canManage && <button className="add-plot-card" onClick={() => {if (requireAuth()) setEditing('new')}}><span><Plus size={28}/></span><strong>添加一块新地</strong><p>让每一份生长，都有迹可循</p></button>}</div>{!canManage && <p className="auto-plot-hint" role="status">登录后可以创建和维护自己的地块。</p>}
    {canManage && editing && <PlotEditor key={`${draftOwner}:${editing === 'new' ? 'new' : editing.id}`} owner={draftOwner} plot={editing === 'new' ? null : editing} crops={crops} onChange={onChange} onClose={() => setEditing(null)} toast={toast}/>}
    {canManage && deleting && <Modal title="移除地块" onClose={() => !busy && setDeleting(null)}><p className="modal-message">确定移除「{deleting.name}」吗？该地块关联的历史检测样本将保留。</p><div className="modal-actions"><button className="button outline" disabled={busy} onClick={() => setDeleting(null)}>取消</button><button className="button danger" disabled={busy} onClick={remove}>{busy ? '移除中…' : '确认移除'}</button></div></Modal>}
  </>
}

export function KnowledgePage({articles, children}: {articles: Article[]; children?: ReactNode}) {
  const crops = Array.from(new Set(articles.map(article => article.crop).filter(Boolean)))
  const [search, setSearch] = useState('')
  const [crop, setCrop] = useState('')
  const [selected, setSelected] = useState<Article | null>(null)
  const filtered = articles.filter(article => (!crop || article.crop === crop) && `${article.title}${article.summary}${article.crop}`.includes(search))
  return <><div className="knowledge-banner"><div><span className="hero-label"><BookOpen size={15}/>小禾的田间笔记</span><h2>多懂一点，离丰收更近一点。</h2><p>从叶片观察到日常管理，把知识种在田间。</p></div><Xiaohe state="think"/></div>{children}<div className="knowledge-toolbar"><div className="crop-tabs">{['', ...crops].map(item => <button className={crop === item ? 'active' : ''} key={item} onClick={() => setCrop(item)}>{item || '全部作物'}</button>)}</div><div className="input-search"><Search size={17}/><input aria-label="搜索知识库" placeholder="搜索病害与养护知识" value={search} onChange={event => setSearch(event.target.value)}/></div></div><div className="knowledge-grid">{filtered.map((article, index) => <button className="panel article-card" key={article.id} onClick={() => setSelected(article)}><div className={`article-cover article-color-${index % 4}`}><span className="article-category">{article.category}</span><Leaf className="article-leaf leaf-back" size={120} strokeWidth={.65}/><Sprout className="article-leaf" size={110} strokeWidth={.8}/><span className="article-cover-caption">{(article.crop || '通用').toUpperCase()} / FIELD NOTES</span></div><div className="article-body"><span className="article-crop">{article.crop || '通用'} · 田间知识</span><h2>{article.title}</h2><p>{article.summary}</p><span className="read-article">阅读笔记<ArrowUpRight size={15}/></span></div></button>)}</div>{!filtered.length && <Empty title="暂时没有相关内容" description="换一个关键词，或选择其他作物分类。"/>}<p className="knowledge-disclaimer"><CircleAlert size={14}/>知识内容用于一般种植学习，实际病害请结合现场情况由农技人员确认。</p>{selected && <Modal wide title={selected.title} onClose={() => setSelected(null)}><div className="article-content"><span className="badge healthy">{selected.crop || '通用'} · {selected.category}</span><p className="article-intro">{selected.summary}</p>{selected.content.split('\n').filter(Boolean).map((paragraph, index) => <p key={index}>{paragraph}</p>)}{selected.sources?.length ? <div className="article-sources"><span>延伸阅读 · 专业资料</span>{selected.sources.map(source => <a key={source.url} href={source.url} target="_blank" rel="noreferrer">{source.title}<ArrowUpRight size={14}/></a>)}</div> : null}<div className="notice"><Sprout size={18}/><p>日常巡田、及时记录，与专业农技人员一起做好作物管理。</p></div></div></Modal>}</>
}

export function ModelsPage({model, health, children}: {model: ModelInfo; health: Health | null; children?: ReactNode}) {
  const targetDetection=model.active?.task==='detect'
  const top1=model.active?.test_top1,macroF1=model.active?.test_macro_f1
  const evaluation=!model.active?'准备数据集，训练并验证作物识别模型。':targetDetection?'已完成目标检测接入校验；尚未提供可核验的独立检测评估指标，不沿用分类 Top-1 / F1。':typeof top1==='number'&&Number.isFinite(top1)&&typeof macroF1==='number'&&Number.isFinite(macroF1)?`独立测试集 Top-1 ${(top1*100).toFixed(2)}%，宏平均 F1 ${(macroF1*100).toFixed(2)}%。`:'当前发布模型未提供可核验的独立测试指标。'
  return <><section className="panel model-hero"><div className="model-icon"><FlaskConical size={35}/></div><div><span className={`badge ${model.active ? 'healthy' : 'awaiting_model'}`}>{model.active ? '模型已启用' : '等待训练模型'}</span><h2>{model.active?.name || '下一步，让小禾学会观察。'}</h2><p>{model.message || '检测流程与数据存储已准备就绪，接入训练好的模型即可启用图像分析。'}</p></div><img src="/images/xiaohe.png" alt="等待学习的小禾"/></section>{children}<RunningModels model={model}/><div className="model-grid"><section className="panel model-details"><div className="panel-header"><h2>推理服务状态</h2><span className="quiet">INFERENCE ENGINE</span></div><dl className="status-list"><div><dt><Server size={17}/>应用服务</dt><dd><span className="live-dot"/>{health?.status === 'ok' ? '运行中' : '服务可访问'}</dd></div><div><dt><HardDrive size={17}/>数据存储</dt><dd>{connectionLabel(health?.database)}</dd></div><div><dt><Layers3 size={17}/>主要识别模型</dt><dd>{model.active?.name || '尚未配置'}</dd></div><div><dt><Settings2 size={17}/>主模型适配器</dt><dd>{model.active ? `ONNX · ${model.active.class_count} 类${targetDetection?'目标检测':'叶片分类'}` : '待训练模型验证'}</dd></div></dl><div className="model-supported"><span>{model.active ? '模型支持作物' : '当前可采集作物'}</span><div>{(model.active ? model.supported_crops : model.available_crops).map(crop => <span key={crop}><CropIcon crop={crop} size={26}/>{crop}</span>)}</div></div></section><section className="panel model-roadmap"><div className="panel-header"><h2>接入流程</h2><Sprout size={20}/></div>{[['基础系统', '图片上传、样本管理与数据存储已就绪。', true], [targetDetection?'训练与接入校验':'训练与验证', evaluation, !!model.active], ['适配推理接口', 'ONNX 推理、类别映射与置信度校验。', !!model.active], ['上线识别', '启用后分析新上传的图片；历史待检测样本保留原状态。', !!model.active]].map(([title, description, done], index) => <div className={`roadmap-step ${done ? 'done' : ''}`} key={String(title)}><span>{done ? <Check size={15}/> : index + 1}</span><div><h3>{title}</h3><p>{description}</p></div></div>)}</section></div><div className="notice"><ShieldCheck size={19}/><div><strong>结果真实，才能判断可靠</strong><p>没有加载并验证模型时，上传记录会保留为“等待模型”，不会生成模拟识别结果。</p></div></div></>
}

export function SettingsPage({health, user, onLogin, onLogout}: {health: Health | null; user: User | null; onLogin: () => void; onLogout: () => void}) {
  const [compact, setCompact] = useState(localStorage.getItem('agriscan-compact') === 'true')
  const [motion, setMotion] = useState(localStorage.getItem('agriscan-motion') !== 'false')
  const [saved, setSaved] = useState('')
  useEffect(() => {if (!saved) return; const timer = setTimeout(() => setSaved(''), 2600); return () => clearTimeout(timer)}, [saved])
  const change = (key: string, value: boolean) => {setSaved(`${key === 'compact' ? '布局' : '动效'}偏好已保存`); localStorage.setItem(`agriscan-${key}`, String(value)); document.documentElement.classList.toggle(key === 'compact' ? 'compact' : 'reduce-motion', key === 'compact' ? value : !value)}
  return <>{saved && <div className="preference-feedback" role="status"><CheckCircle2 size={16}/>{saved}</div>}<div className="settings-grid"><section className="panel settings-panel"><div className="panel-header"><h2>个人与偏好</h2><Settings2 size={19}/></div><div className="account-card"><div className="avatar">{user ? user.name.charAt(0) : '访'}</div><div><strong>{user?.name || '访客'}</strong><p>{user ? (user.role === 'admin' ? '管理员 · 此处仅管理我的地块与样本' : '普通成员 · 管理我的地块与检测记录') : '登录后可以上传样本、管理地块'}</p></div><button className="button outline" onClick={user ? onLogout : onLogin}>{user ? '退出登录' : '登录账户'}</button></div><div className="setting-row"><div><strong>紧凑布局</strong><p>缩小表格行距，在同一屏展示更多记录</p></div><button className={`switch ${compact ? 'on' : ''}`} role="switch" aria-checked={compact} aria-label="紧凑布局" onClick={() => {setCompact(!compact); change('compact', !compact)}}><span/></button></div><div className="setting-row"><div><strong>界面动效</strong><p>小禾逐帧动画与界面过渡，关闭后显示静态形象</p></div><button className={`switch ${motion ? 'on' : ''}`} role="switch" aria-checked={motion} aria-label="界面动效" onClick={() => {setMotion(!motion); change('motion', !motion)}}><span/></button></div></section><section className="panel settings-panel"><div className="panel-header"><h2>系统信息</h2><Leaf size={19}/></div><dl className="status-list"><div><dt>系统名称</dt><dd>AgriScan 禾观</dd></div><div><dt>版本</dt><dd>{import.meta.env.VITE_RELEASE_VERSION ? `${import.meta.env.VITE_RELEASE_VERSION} · 网页工作台` : '开发版本 · 网页工作台'}</dd></div><div><dt>运行模式</dt><dd>{health?.mode === 'demo' ? '演示模式' : '标准模式'}</dd></div><div><dt>数据库</dt><dd>{connectionLabel(health?.database)}</dd></div><div><dt>Redis</dt><dd>{connectionLabel(health?.redis)}</dd></div><div><dt>技术栈</dt><dd>React · FastAPI</dd></div></dl>{import.meta.env.DEV && <a href="/docs" target="_blank" rel="noreferrer" className="text-button api-link">本地 API 文档 <ArrowUpRight size={15}/></a>}</section></div>{user&&<AccountEmailSettings key={`${user.username}:${getToken()}`}/>}<XiaoheMotionDemo/></>
}

function connectionLabel(status?: string) { return status === 'connected' ? '已连接' : status === 'disabled' ? '本地演示未启用' : status === 'unavailable' ? '连接异常' : status || '未连接' }
